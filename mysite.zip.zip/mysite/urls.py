from django.contrib import admin
from django.urls import path
from django.shortcuts import render, redirect
from core.models import Student
from core.forms import StudentForm

# 1. HOME VIEW (List chupinchadaniki)
def home(request):
    students = Student.objects.all()
    return render(request, 'home.html', {'students': students})

# 2. ADD VIEW (Kotha student)
def add_student(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(home)
    else:
        form = StudentForm()
    return render(request, 'add.html', {'form': form})

# 3. DELETE VIEW
def delete_student(request, id):
    student = Student.objects.get(id=id)
    student.delete()
    return redirect(home)

# 4. UPDATE VIEW (Edit cheyadaniki)
def update_student(request, id):
    student = Student.objects.get(id=id)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect(home)
    else:
        form = StudentForm(instance=student)
    return render(request, 'update.html', {'form': form})

# URL PATTERNS
urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('', home),  # <--- Ee line miss ayyindi indaka! (Home Page)
    path('add/', add_student),
    path('delete/<int:id>/', delete_student),
    path('update/<int:id>/', update_student),
]